alert('WELCOME TO CYLEVIRE BLOG! \nHope You Enjoy It..')

//const digunakan untuk mendeklarasikan variabel yang nilainya tidak akan berubah setelah diberikan nilai awal. 
const header = document.querySelector('header'); //Baris ini mendapatkan referensi ke elemen <header> di doc myblogp1.html menggunakan metode document.querySelector(). Referensi tersebut disimpan dalam variabel header.
        window.addEventListener('scroll', function() { //event listener menangkap event scroll pada window. Sehingga ketika user scrolling layar, fungsi callback yang diberikan sebagai argumen akan dieksekusi.
            if (window.scrollY > 50) { //kondisi yang memeriksa apakah jarak scroll vertikal (window.scrollY) > 50px. Jika iya, maka kode di bawah dijalankan
                header.style.backgroundColor = 'darkseagreen'; //mengatur warna background color
                header.style.color = 'darkslategray'; //mengatur warna teks
                header.style.textShadow = '1px 1px 1px white'; //mengatur bayangan teks
            } else { //jika < 50px, kode dibawah dijalankan
                header.style.backgroundColor = 'darkslategray'; //mengatur warna background color
                header.style.color = 'antiquewhite'; //mengatur warna teks
            }
        });